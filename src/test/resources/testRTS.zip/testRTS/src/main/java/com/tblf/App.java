package com.tblf;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
    }

    public void foo() {
        System.out.println("Hello, w0rld!");
    }

    public void bar() {
        System.out.println("I'm going to say hello world, see !");
        foo();
    }
}
