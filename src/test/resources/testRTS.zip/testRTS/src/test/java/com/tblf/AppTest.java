package com.tblf;

import org.junit.Test;

public class AppTest 
{
    @Test
    public void firstUnitTestMethod()
    {
        App app = new App();
        app.foo();
    }

    @Test
    public void secondUnitTestMethod()
    {
        App app = new App();
        app.bar();
    }
}
