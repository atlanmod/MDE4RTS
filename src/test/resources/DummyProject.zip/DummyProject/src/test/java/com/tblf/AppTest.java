package com.tblf;

import org.junit.Test;

public class AppTest {
    @Test
    public void shouldAnswerWithTrue() {
        App.main(new String[]{});
    }
}
