package com.tblf;

public class AppChild extends App {


    
    @Override
    public void methodThatWillBeOverriden() {
        System.out.println("Hey~!");
    }

}
