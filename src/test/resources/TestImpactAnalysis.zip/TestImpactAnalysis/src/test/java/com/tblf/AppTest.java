package com.tblf;

import org.junit.Test;

import static org.junit.Assert.assertTrue;

/**
 * Unit test for simple App.
 */
public class AppTest 
{
    @Test
    public void testDirectCall()
    {
        new SuperApp().main("Super hi");
    }

    @Test
    public void testInheritedCall()
    {
        new App().main("Hi");
    }

    @Test
    public void testMultipleCall()
    {
        SuperApp app = new SuperApp();
        app.main("1- Hi");
        app.main("2- Hi");
    }
}
