package com.tblf;

import java.util.Arrays;

public class SuperApp {
    void main( String ... args )
    {
        System.out.println(Arrays.toString(args) +" World!" );
    }
}
