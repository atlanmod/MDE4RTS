package com.tblf;

public class ParentClass {

    public ParentClass() {
        System.out.println("Parent class initialized");
    }

    public void method() {
        System.out.println("Hello, world");
    }

    public void otherMethod() {
        System.out.println("other method called");
    }
}
