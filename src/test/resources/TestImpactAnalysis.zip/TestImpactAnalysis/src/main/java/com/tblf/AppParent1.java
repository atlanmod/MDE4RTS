package com.tblf;

public class AppParent1 extends AppParent2 {

}
