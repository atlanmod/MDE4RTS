package com.tblf;

/**
 * Hello world!
 *
 */
public class App extends ParentClass
{
    @Override
    public void method() {
        System.out.println("Hello world !!!");
    }
}
