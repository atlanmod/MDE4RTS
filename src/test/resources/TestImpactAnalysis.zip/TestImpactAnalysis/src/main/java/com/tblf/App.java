package com.tblf;

import java.util.Arrays;

/**
 * Hello world!
 *
 */
public class App extends SuperApp
{

}
