package com.tblf;

/**
 * Hello world!
 *
 */
public class App extends AppParent1 {
    //TODO
	@Override
	public int foo() {
		// TODO Auto-generated method stub
		return super.foo() + 1;
	}
	
}
