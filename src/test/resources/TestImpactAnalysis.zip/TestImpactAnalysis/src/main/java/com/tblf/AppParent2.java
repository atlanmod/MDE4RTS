package com.tblf;

public class AppParent2{
	public int foo() {
		return 5;
	}
}
