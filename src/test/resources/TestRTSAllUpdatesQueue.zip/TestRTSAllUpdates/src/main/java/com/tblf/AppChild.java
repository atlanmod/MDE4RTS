package com.tblf;

public class AppChild extends App {

    @Override
    public void methodThatWillBeOverriden() {
        System.out.println("My mother had this method before. Now I do !");
    }

}
