package root;

import org.junit.Assert;
import org.junit.Test;

public class TestApp {

    @Test
    public void testTrue() {
        Assert.assertTrue(new AppChild().foo());
    }

    @Test
    public void testFalse() {
        Assert.assertTrue(new App().foo());
    }

    @Test
    public void testInheritance() {
        Assert.assertTrue(new AppChild().bar());
    }

    @Test
    public void testInheritance2() {
        Assert.assertTrue(new AppChild2().bar());
    }

    @Test
    public void testAdded() {
      System.out.println("This is a new test");
    }
}
