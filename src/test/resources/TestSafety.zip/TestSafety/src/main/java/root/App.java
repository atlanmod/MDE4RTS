package root;

public class App {

    public boolean foo() {
        int i = 1;
        int j = 1;
        return i == j;
    }

    public boolean bar() {
        int i = 0;
        int j = 0;
        return i != j;
    }
}
