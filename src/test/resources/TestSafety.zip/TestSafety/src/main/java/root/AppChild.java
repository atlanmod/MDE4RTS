package root;

public class AppChild extends App {

    @Override
    public boolean foo() {
        return super.foo();
    }

    
}
