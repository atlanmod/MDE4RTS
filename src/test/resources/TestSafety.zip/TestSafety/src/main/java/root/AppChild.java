package root;

public class AppChild extends App {

    @Override
    public boolean foo() {
        return super.foo();
    }

    @Override
    public boolean bar() {
        return !super.bar();
    }
}
