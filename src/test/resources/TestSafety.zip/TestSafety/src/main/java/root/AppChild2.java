package root;

public class AppChild2 extends App {

	@Override
	public boolean bar() {
		return !super.bar();
	}
	
}
