package root;

public class AppChild2 extends App {


	
}
