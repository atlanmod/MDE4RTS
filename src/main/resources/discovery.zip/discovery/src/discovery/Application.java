package discovery;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.eclipse.cdt.managedbuilder.internal.core.HeadlessBuilder;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.NullProgressMonitor;
import org.eclipse.equinox.app.IApplication;
import org.eclipse.equinox.app.IApplicationContext;
import org.eclipse.jdt.core.IJavaProject;
import org.eclipse.jdt.core.JavaCore;
import org.eclipse.jdt.internal.core.JavaProject;
import org.eclipse.modisco.java.discoverer.DiscoverJavaModelFromJavaProject;

/**
 * This class controls all aspects of the application's execution
 */
public class Application implements IApplication {

	@SuppressWarnings("restriction")
	@Override
	public Object start(IApplicationContext context) throws Exception {
	
		HeadlessBuilder builder = new HeadlessBuilder();		
		String[] args = (String[]) context.getArguments().get(IApplicationContext.APPLICATION_ARGS);
		
		if (args.length == 0) {
			System.out.println("No arg given. Exiting...");
			System.exit(0);
		}
		
		File project = null;		
		for (int i = 0; i < args.length; i++) {
			if ("-project".equals(args[i])) {
				args[i] = "-import";
				project = new File(args[++i]);
				if (project.exists())
					System.out.println("Discovering the project: "+project.getAbsolutePath());
				else 
					System.out.println("The project given could not be found.");
			}
		}
				
		generateProjectDescription(project);		

		builder.start(context);
		
		IProject iProject = null;
		
		for (IProject p : ResourcesPlugin.getWorkspace().getRoot().getProjects()) {
			System.out.println(p.getName());
			if (p.getName().equals(project.getName())) {
				iProject = p;
			}			
		}
			
		System.out.println(ResourcesPlugin.getWorkspace().getRoot().getFullPath());
		
		try {
			if (iProject == null) {
				System.out.println("importing the project");
				iProject = ResourcesPlugin.getWorkspace().getRoot().getProject(project.getName());
				iProject.open(new NullProgressMonitor());
			}
			
			IJavaProject javaProject = JavaCore.create(iProject);
			if (javaProject == null)
				throw new Exception("JavaCore cannot create the JavaProject ");
		} catch (Exception e) {
			Logger.getAnonymousLogger().log(Level.WARNING, "Could not load the Java project", e);
			System.exit(1);
		}
		
		DiscoverJavaModelFromJavaProject discoverJavaModelFromJavaProject = new DiscoverJavaModelFromJavaProject();
		discoverJavaModelFromJavaProject.setSerializeTarget(true);
		discoverJavaModelFromJavaProject.setRefreshSourceBeforeDiscovery(true);
		discoverJavaModelFromJavaProject.setDeepAnalysis(true);
		discoverJavaModelFromJavaProject.discoverElement(JavaCore.create(iProject), new NullProgressMonitor());	
//				
		return IApplication.EXIT_OK;
	}

	private void generateProjectDescription(File project) {
		File f = new File(project, ".project");		
		try {
			if (f.exists())
				f.delete();
			
			f.createNewFile();
			FileWriter fw;
			fw = new FileWriter(f);
			
			fw.write("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" + 
					"<projectDescription>\n" + 
					"	<name>");
			fw.write(project.getName());
			fw.write("</name>\n" + 
					"	<comment></comment>\n" + 
					"	<projects>\n" + 
					"	</projects>\n" + 
					"	<buildSpec>\n" + 
					"		<buildCommand>\n" + 
					"			<name>org.eclipse.jdt.core.javabuilder</name>\n" + 
					"			<arguments>\n" + 
					"			</arguments>\n" + 
					"		</buildCommand>\n" + 
					"		<buildCommand>\n" + 
					"			<name>org.eclipse.m2e.core.maven2Builder</name>\n" + 
					"			<arguments>\n" + 
					"			</arguments>\n" + 
					"		</buildCommand>\n" + 
					"	</buildSpec>\n" + 
					"	<natures>\n" + 
					"		<nature>org.eclipse.jdt.core.javanature</nature>\n" + 
					"		<nature>org.eclipse.m2e.core.maven2Nature</nature>\n" + 
					"	</natures>\n" + 
					"</projectDescription>");
			fw.close();
		} catch (IOException e) {
			e.printStackTrace();
		}		
	}
	
	@Override
	public void stop() {
		// nothing to do
	}
}
